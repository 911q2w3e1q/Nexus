package net.nexus;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.KeyMapping.Category;
import net.nexus.hack.Hack;
import net.nexus.hack.HackList;
import net.nexus.util.Translate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class NexusClient implements ClientModInitializer
{
	public static final String NAME = "Nexus Client";
	public static final String VERSION = "a1.0";
	public static final String MC_VERSION = "1.21.11";
	
	private static NexusClient INSTANCE;
	public final Minecraft MC = Minecraft.getInstance();
	public final HackList hackList = new HackList();
	private boolean guiKeyWasDown;
	
	@Override
	public void onInitializeClient()
	{
		INSTANCE = this;
		System.out.println("[NEXUS] onInitializeClient OK");
		
		// 注册按键：右Ctrl=选项界面、右Shift=搜索界面
		openGuiKey = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.nexus.gui", 345, Category.MISC));
		openSearchKey = KeyBindingHelper.registerKeyBinding(
			new KeyMapping("key.nexus.search", 344, Category.MISC));
		
		// 沙箱测试钩子：仅 NEXUS_TEST_GUI=1 环境变量时触发
		if(System.getenv("NEXUS_TEST_GUI") != null)
			testGuiMode = 1;
		
		// 每 tick
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			onTick();
			handleGuiKey();
		});
		
		// HUD 渲染
		HudRenderCallback.EVENT.register((graphics, tickDelta) -> {
			renderHud(graphics);
		});
	}
	
	public static NexusClient getInstance()
	{
		return INSTANCE;
	}
	
	public void onTick()
	{
		hackList.onTick();
		runTestHook();
	}
	
	private void runTestHook()
	{
		if(testGuiMode < 0 || MC.player == null)
			return;
		
		testGuiTicks++;
		if(testGuiTicks == 150)
			MC.setScreen(new net.nexus.gui.ClickGuiScreen());
		else if(testGuiTicks == 350)
			MC.setScreen(new net.nexus.gui.NavigatorScreen());
		else if(testGuiTicks == 500)
		{
			MC.setScreen(null);
			testGuiMode = -1;
		}
	}
	
	private KeyMapping openGuiKey;
	private KeyMapping openSearchKey;
	private int testGuiMode;
	private int testGuiTicks;
	
	private void handleGuiKey()
	{
		// 右Ctrl = 选项界面
		if(openGuiKey.consumeClick())
		{
			if(MC.screen == null)
				MC.setScreen(new net.nexus.gui.ClickGuiScreen());
			else if(MC.screen instanceof net.nexus.gui.ClickGuiScreen)
				MC.setScreen(null);
		}
		
		// 右Shift = 搜索界面
		if(openSearchKey.consumeClick())
		{
			if(MC.screen == null)
				MC.setScreen(new net.nexus.gui.NavigatorScreen());
			else if(MC.screen instanceof net.nexus.gui.NavigatorScreen)
				MC.setScreen(null);
		}
	}
	
	private void renderHud(GuiGraphics graphics)
	{
		if(MC.options.hideGui)
			return;
		
		// 左上角标题
		graphics.drawString(MC.font, NAME + " " + VERSION + " " + MC_VERSION,
			2, 2, 0xFFFFFF);
		
		// 已启用功能列表
		int y = 14;
		for(Hack hack : hackList.getAll())
		{
			if(!hack.isEnabled())
				continue;
			graphics.drawString(MC.font, Translate.name(hack.getName()),
				2, y, 0x00FF00);
			y += 10;
			if(y > 100)
				break;
		}

	}
}
