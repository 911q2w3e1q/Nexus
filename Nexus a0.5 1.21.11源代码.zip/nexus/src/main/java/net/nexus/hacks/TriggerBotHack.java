package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;

public final class TriggerBotHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public final Setting range = new Setting("范围", 6f, 2f, 10f, 0.5f);
	
	public TriggerBotHack()
	{
		super("TriggerBot", "战斗");
		addSetting(range);
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.hitResult == null)
			return;
		
		if(MC.hitResult instanceof EntityHitResult hit)
		{
			if(MC.player.distanceTo(hit.getEntity()) > range.value)
				return;
			MC.gameMode.attack(MC.player, hit.getEntity());
			MC.player.swing(InteractionHand.MAIN_HAND);
		}
	}
}
