package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.List;

public final class KillauraHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int tick;
	
	public final Setting range = new Setting("范围", 4.25f, 2f, 8f, 0.25f);
	public final Setting speed = new Setting("攻击间隔", 1f, 1f, 10f, 1f);
	public final Setting autoRotate = new Setting("自动旋转", true);
	public final Setting targetPlayers = new Setting("攻击玩家", true);
	public final Setting targetMobs = new Setting("攻击怪物", true);
	
	public KillauraHack()
	{
		super("Killaura", "战斗");
		addSetting(range);
		addSetting(speed);
		addSetting(autoRotate);
		addSetting(targetPlayers);
		addSetting(targetMobs);
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		tick++;
		if(tick < (int)speed.value)
			return;
		tick = 0;
		
		// 用 getEntities 枚举（比 entitiesForRendering 更可靠）
		double reach = range.value;
		AABB box = MC.player.getBoundingBox().inflate(reach + 1);
		List<Entity> list = MC.level.getEntities(MC.player, box,
			e -> e != MC.player && e.isAlive()
				&& (e instanceof LivingEntity));
		
		Entity target = null;
		double bestDist = reach;
		for(Entity e : list)
		{
			if(e instanceof Player p)
			{
				if(!targetPlayers.boolValue)
					continue;
			}
			else if(e instanceof Monster)
			{
				if(!targetMobs.boolValue)
					continue;
			}
			else
				continue;
			
			double d = MC.player.distanceTo(e);
			if(d < bestDist)
			{
				bestDist = d;
				target = e;
			}
		}
		
		if(target == null)
			return;
		
		// 自动旋转
		if(autoRotate.boolValue)
		{
			double dx = target.getX() - MC.player.getX();
			double dz = target.getZ() - MC.player.getZ();
			float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx))
				- 90);
			MC.player.setYRot(yaw);
		}
		
		MC.gameMode.attack(MC.player, target);
		MC.player.swing(InteractionHand.MAIN_HAND);
	}
}
