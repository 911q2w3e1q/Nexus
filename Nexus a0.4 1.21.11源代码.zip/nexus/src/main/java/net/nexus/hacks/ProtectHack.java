package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public final class ProtectHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public ProtectHack()
	{
		super("Protect", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		// 攻击最近的其他玩家（保护自己）
		Entity target = null;
		double best = ReachHack.getReach();
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(e == MC.player || !e.isAlive())
				continue;
			if(!(e instanceof Player))
				continue;
			double d = MC.player.distanceTo(e);
			if(d < best)
			{
				best = d;
				target = e;
			}
		}
		
		if(target != null)
		{
			MC.gameMode.attack(MC.player, target);
			MC.player.swing(InteractionHand.MAIN_HAND);
		}
	}
}
