package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;

public final class LiquidInteractHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public LiquidInteractHack()
	{
		super("LiquidInteract", "世界");
	}
	
	@Override
	public void onTick()
	{
		// 允许与液体交互（放置/破坏）
	}
}
