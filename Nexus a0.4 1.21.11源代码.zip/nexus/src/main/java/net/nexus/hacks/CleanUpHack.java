package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.item.ItemEntity;

public final class CleanUpHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public CleanUpHack()
	{
		super("CleanUp", "其他");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		for(var e : MC.level.entitiesForRendering())
			if(e instanceof ItemEntity item && MC.player.distanceTo(item) < 3)
				MC.gameMode.attack(MC.player, item);
	}
}
