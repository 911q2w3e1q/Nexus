package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

public final class KillauraHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public KillauraHack()
	{
		super("Killaura", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		Entity target = null;
		double bestDist = 4.25;
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(e == MC.player || !e.isAlive())
				continue;
			if(!(e instanceof Monster) && !(e instanceof Player))
				continue;
			
			double d = MC.player.distanceTo(e);
			if(d < bestDist)
			{
				bestDist = d;
				target = e;
			}
		}
		
		if(target == null)
			return;
		
		MC.gameMode.attack(MC.player, target);
		MC.player.swing(InteractionHand.MAIN_HAND);
	}
}
