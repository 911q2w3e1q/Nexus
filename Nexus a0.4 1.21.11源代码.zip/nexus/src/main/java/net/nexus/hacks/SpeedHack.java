package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public final class SpeedHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public SpeedHack()
	{
		super("Speed", "移动");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || !MC.player.onGround())
			return;
		
		Vec3 v = MC.player.getDeltaMovement();
		MC.player.setDeltaMovement(v.x * 1.4, v.y, v.z * 1.4);
	}
}
