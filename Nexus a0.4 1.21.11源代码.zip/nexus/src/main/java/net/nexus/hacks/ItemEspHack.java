package net.nexus.hacks;

public final class ItemEspHack extends EspHackBase
{
	private static boolean active;
	private static int colorIndex; // 默认白
	
	public ItemEspHack()
	{
		super("ItemESP", "渲染");
	}
	
	public static boolean isActive()
	{
		return active;
	}
	
	public static int getColor()
	{
		return COLORS[colorIndex];
	}
	
	public static String getColorName()
	{
		return COLOR_NAMES[colorIndex];
	}
	
	public static int nextColorIndex()
	{
		colorIndex = (colorIndex + 1) % COLORS.length;
		return colorIndex;
	}
	
	@Override
	protected void onEnable()
	{
		active = true;
	}
	
	@Override
	protected void onDisable()
	{
		active = false;
	}
}
