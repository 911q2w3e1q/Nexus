package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;

public final class NameTagsHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public NameTagsHack()
	{
		super("NameTags", "渲染");
	}
	
	@Override
	public void onTick()
	{
		// 通过渲染事件处理
	}
}
