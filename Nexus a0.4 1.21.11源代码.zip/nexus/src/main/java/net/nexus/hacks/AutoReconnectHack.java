package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;

public final class AutoReconnectHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int ticks;
	
	public AutoReconnectHack()
	{
		super("AutoReconnect", "其他");
	}
	
	@Override
	public void onTick()
	{
		if(MC.screen instanceof DisconnectedScreen)
		{
			ticks++;
			if(ticks > 100)
			{
				ticks = 0;
				MC.setScreen(new JoinMultiplayerScreen(
					new net.minecraft.client.gui.screens.TitleScreen()));
			}
		}
		else
		{
			ticks = 0;
		}
	}
}
