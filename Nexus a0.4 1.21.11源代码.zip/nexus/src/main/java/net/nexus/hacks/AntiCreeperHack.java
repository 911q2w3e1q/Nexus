package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Creeper;

public final class AntiCreeperHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public AntiCreeperHack()
	{
		super("AntiCreeper", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(!(e instanceof Creeper) || !e.isAlive())
				continue;
			
			if(MC.player.distanceTo(e) <= 4)
			{
				MC.gameMode.attack(MC.player, e);
				MC.player.swing(InteractionHand.MAIN_HAND);
				return;
			}
		}
	}
}
