package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BedBlock;

public final class BedAuraHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int tick;
	
	public BedAuraHack()
	{
		super("BedAura", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		tick++;
		if(tick < 5)
			return;
		tick = 0;
		
		BlockPos center = MC.player.blockPosition();
		for(int dx = -4; dx <= 4; dx++)
			for(int dy = -2; dy <= 2; dy++)
				for(int dz = -4; dz <= 4; dz++)
				{
					BlockPos pos = center.offset(dx, dy, dz);
					if(MC.level.getBlockState(pos).getBlock()
						instanceof BedBlock)
					{
						MC.gameMode.destroyBlock(pos);
						return;
					}
				}
	}
}
