package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public final class GlideHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public GlideHack()
	{
		super("Glide", "移动");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null)
			return;
		
				Vec3 v = MC.player.getDeltaMovement();
		if(!MC.player.onGround() && v.y < -0.1)
			MC.player.setDeltaMovement(v.x, -0.1, v.z);
	}
}
