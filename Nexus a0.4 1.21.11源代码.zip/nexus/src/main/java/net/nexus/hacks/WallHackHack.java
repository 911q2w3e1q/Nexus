package net.nexus.hacks;

import net.nexus.hack.Hack;

public final class WallHackHack extends Hack
{
	private static boolean active;
	
	public WallHackHack()
	{
		super("WallHack", "世界");
	}
	
	public static boolean isActive()
	{
		return active;
	}
	
	@Override
	protected void onEnable()
	{
		active = true;
	}
	
	@Override
	protected void onDisable()
	{
		active = false;
	}
}
