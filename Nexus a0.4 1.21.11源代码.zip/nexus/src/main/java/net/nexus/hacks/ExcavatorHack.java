package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class ExcavatorHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int tick;
	
	public ExcavatorHack()
	{
		super("Excavator", "世界");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		tick++;
		if(tick < 4)
			return;
		tick = 0;
		
		BlockPos center = MC.player.blockPosition();
		for(int dy = -1; dy <= 0; dy++)
			for(int dx = -1; dx <= 1; dx++)
				for(int dz = -1; dz <= 1; dz++)
				{
					BlockPos pos = center.offset(dx, dy, dz);
					if(MC.level.getBlockState(pos).isAir())
						continue;
					MC.gameMode.destroyBlock(pos);
					return;
				}
	}
}
