package net.nexus.hacks;

public final class MobEspHack extends EspHackBase
{
	private static boolean active;
	private static int colorIndex = 1; // 默认红
	
	public MobEspHack()
	{
		super("MobESP", "渲染");
	}
	
	public static boolean isActive()
	{
		return active;
	}
	
	public static int getColor()
	{
		return COLORS[colorIndex];
	}
	
	public static String getColorName()
	{
		return COLOR_NAMES[colorIndex];
	}
	
	public static int nextColorIndex()
	{
		colorIndex = (colorIndex + 1) % COLORS.length;
		return colorIndex;
	}
	
	@Override
	protected void onEnable()
	{
		active = true;
	}
	
	@Override
	protected void onDisable()
	{
		active = false;
	}
}
