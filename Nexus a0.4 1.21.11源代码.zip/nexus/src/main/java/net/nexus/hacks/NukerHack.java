package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

public final class NukerHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public NukerHack()
	{
		super("Nuker", "世界");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		BlockPos center = MC.player.blockPosition();
		for(int dx = -2; dx <= 2; dx++)
			for(int dy = -2; dy <= 2; dy++)
				for(int dz = -2; dz <= 2; dz++)
				{
					BlockPos pos = center.offset(dx, dy, dz);
					if(MC.level.getBlockState(pos).isAir())
						continue;
					MC.gameMode.destroyBlock(pos);
					return;
				}
	}
}
