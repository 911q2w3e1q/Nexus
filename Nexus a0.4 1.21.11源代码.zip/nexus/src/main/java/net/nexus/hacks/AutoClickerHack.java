package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;

public final class AutoClickerHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int counter;
	
	public AutoClickerHack()
	{
		super("AutoClicker", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || !MC.options.keyAttack.isDown())
			return;
		
		counter++;
		if(counter < 2)
			return;
		counter = 0;
		
		if(MC.hitResult instanceof EntityHitResult hit)
		{
			MC.gameMode.attack(MC.player, hit.getEntity());
			MC.player.swing(InteractionHand.MAIN_HAND);
		}
	}
}
