package net.nexus.hacks;

import net.nexus.hack.Hack;

public final class ReachHack extends Hack
{
	private static boolean active;
	private static double reach = 4.25;
	
	public ReachHack()
	{
		super("Reach", "战斗");
	}
	
	public static boolean isActive()
	{
		return active;
	}
	
	public static double getReach()
	{
		return active ? 6.0 : reach;
	}
	
	@Override
	protected void onEnable()
	{
		active = true;
	}
	
	@Override
	protected void onDisable()
	{
		active = false;
	}
}
