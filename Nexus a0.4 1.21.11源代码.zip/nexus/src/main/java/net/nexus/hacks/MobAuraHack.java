package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;

public final class MobAuraHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public MobAuraHack()
	{
		super("MobAura", "战斗");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.level == null)
			return;
		
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(e == MC.player || !e.isAlive())
				continue;
			if(!(e instanceof Monster))
				continue;
			double reach = ReachHack.getReach();
			if(MC.player.distanceTo(e) > reach)
				continue;
			
			MC.gameMode.attack(MC.player, e);
			MC.player.swing(InteractionHand.MAIN_HAND);
			return;
		}
	}
}
