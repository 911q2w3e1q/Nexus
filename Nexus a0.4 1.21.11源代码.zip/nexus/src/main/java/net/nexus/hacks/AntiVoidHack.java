package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;

public final class AntiVoidHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public AntiVoidHack()
	{
		super("AntiVoid", "移动");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null)
			return;
		
		if(MC.player.getY() < -10)
			MC.player.setDeltaMovement(0, 2, 0);
	}
}
