package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.BlockHitResult;

public final class FastBreakHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int counter;
	
	public FastBreakHack()
	{
		super("FastBreak", "世界");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.hitResult == null)
			return;
		
		if(MC.options.keyAttack.isDown()
			&& MC.hitResult instanceof BlockHitResult hit)
		{
			counter++;
			if(counter % 2 == 0)
				MC.gameMode.destroyBlock(hit.getBlockPos());
		}
	}
}
