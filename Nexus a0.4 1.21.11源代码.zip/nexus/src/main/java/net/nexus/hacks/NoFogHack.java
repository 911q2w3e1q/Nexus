package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;

public final class NoFogHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	
	public NoFogHack()
	{
		super("NoFog", "渲染");
	}
	
	@Override
	public void onTick()
	{
		// 渲染层通过 mixin 处理；这里保持启用状态标记
	}
}
