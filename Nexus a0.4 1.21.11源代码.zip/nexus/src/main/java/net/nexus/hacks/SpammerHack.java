package net.nexus.hacks;

import net.nexus.hack.Hack;
import net.minecraft.client.Minecraft;

public final class SpammerHack extends Hack
{
	private final Minecraft MC = Minecraft.getInstance();
	private int counter;
	
	public SpammerHack()
	{
		super("Spammer", "聊天");
	}
	
	@Override
	public void onTick()
	{
		if(MC.player == null || MC.getConnection() == null)
			return;
		
		counter++;
		if(counter < 40)
			return;
		counter = 0;
		
		MC.getConnection().sendChat("Nexus Client!");
	}
}
