package net.nexus.hack;

public abstract class Hack
{
	private final String name;
	private final String category;
	private boolean enabled;
	
	public Hack(String name, String category)
	{
		this.name = name;
		this.category = category;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getCategory()
	{
		return category;
	}
	
	public boolean isEnabled()
	{
		return enabled;
	}
	
	public void toggle()
	{
		enabled = !enabled;
		if(enabled)
			onEnable();
		else
			onDisable();
	}
	
	public void setEnabled(boolean enabled)
	{
		if(this.enabled == enabled)
			return;
		this.enabled = enabled;
		if(enabled)
			onEnable();
		else
			onDisable();
	}
	
	protected void onEnable()
	{
	}
	
	protected void onDisable()
	{
	}
	
	public void onTick()
	{
	}
}
