package net.nexus.render;

import net.nexus.NexusClient;
import net.nexus.hacks.PlayerEspHack;
import net.nexus.hacks.MobEspHack;
import net.nexus.hacks.ChestEspHack;
import net.nexus.hacks.ItemEspHack;
import net.nexus.util.Translate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

public final class EspRenderer
{
	private static final Minecraft MC = Minecraft.getInstance();
	
	private static final java.util.List<net.minecraft.core.BlockPos>
		chestCache = new java.util.ArrayList<>();
	private static int scanTick;
	private static float partialTick;
	
	public static void render(GuiGraphics g, float tickDelta)
	{
		if(MC.player == null || MC.level == null)
			return;
		
		partialTick = tickDelta;
		
		boolean player = PlayerEspHack.isActive();
		boolean mob = MobEspHack.isActive();
		boolean chest = ChestEspHack.isActive();
		boolean item = ItemEspHack.isActive();
		if(!player && !mob && !chest && !item)
			return;
		
		Vec3 cam = MC.player.getEyePosition(tickDelta);
		int fov = MC.options.fov().get();
		
		// 定时扫描箱子
		scanTick++;
		if(chest && scanTick % 20 == 0)
		{
			chestCache.clear();
			net.minecraft.core.BlockPos center = MC.player.blockPosition();
			for(int dx = -20; dx <= 20; dx++)
				for(int dy = -6; dy <= 6; dy++)
					for(int dz = -20; dz <= 20; dz++)
					{
						net.minecraft.core.BlockPos pos =
							center.offset(dx, dy, dz);
						if(MC.level.getBlockState(pos).getBlock()
							instanceof net.minecraft.world.level.block.ChestBlock)
							chestCache.add(pos);
					}
		}
		
		// 实体
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(e == MC.player)
				continue;
			if(e instanceof Player p && player)
				drawEntity(g, p, cam, fov, PlayerEspHack.getColor(),
					p.getDisplayName().getString());
			else if(e instanceof Monster m && mob)
				drawEntity(g, m, cam, fov, MobEspHack.getColor(),
					m.getType().getDescription().getString());
			else if(e instanceof ItemEntity i && item)
				drawEntity(g, i, cam, fov, ItemEspHack.getColor(),
					i.getItem().getHoverName().getString());
		}
		
		// 箱子
		if(chest)
			for(net.minecraft.core.BlockPos pos : chestCache)
				drawBlock(g, pos.getX() + 0.5, pos.getY() + 0.5,
					pos.getZ() + 0.5, cam, fov,
					ChestEspHack.getColor(), "箱子");
		
		// 血条标签
		if(net.nexus.hacks.HealthTagsHack.isActive())
			for(net.nexus.hacks.HealthTagsHack.HealthTag tag
				: net.nexus.hacks.HealthTagsHack.getTags())
			{
				double[] sp = project(tag.x, tag.y, tag.z, cam, fov);
				if(sp == null)
					continue;
				g.drawString(MC.font, tag.text,
					(int)sp[0] - 12, (int)sp[1] - 4, tag.color, true);
			}
		
		// 足迹线
		if(net.nexus.hacks.BreadcrumbsHack.isActive())
		{
			net.minecraft.world.phys.Vec3 prev = null;
			for(net.minecraft.world.phys.Vec3 pt
				: net.nexus.hacks.BreadcrumbsHack.getTrail())
			{
				if(prev != null)
					drawLine3D(g, new double[] {prev.x, prev.y, prev.z},
						new double[] {pt.x, pt.y, pt.z}, cam, fov,
						0xFF00FFFF);
				prev = pt;
			}
		}
	}
	
	private static void drawEntity(GuiGraphics g, Entity e, Vec3 cam,
		int fov, int color, String name)
	{
		net.minecraft.world.phys.AABB box = e.getBoundingBox();
		double[] c = project(box.getCenter().x, box.getCenter().y,
			box.getCenter().z, cam, fov);
		if(c == null)
			return;
		
		int sx = (int)c[0], sy = (int)c[1];
		double dist = Math.round(e.distanceTo(MC.player) * 10) / 10.0;
		if(dist > 96)
			return;
		
		// 名字 + 距离
		g.drawString(MC.font, name + " " + dist + "m",
			sx - 20, sy - 40, color, true);
		
		// 3D 线框（AABB 12 条边）
		double[][] corners = {
			{box.minX, box.minY, box.minZ},
			{box.maxX, box.minY, box.minZ},
			{box.maxX, box.minY, box.maxZ},
			{box.minX, box.minY, box.maxZ},
			{box.minX, box.maxY, box.minZ},
			{box.maxX, box.maxY, box.minZ},
			{box.maxX, box.maxY, box.maxZ},
			{box.minX, box.maxY, box.maxZ}
		};
		int[][] edges = {{0,1},{1,2},{2,3},{3,0},
			{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
		for(int[] ed : edges)
			drawLine3D(g, corners[ed[0]], corners[ed[1]],
				cam, fov, color);
	}
	
	private static void drawBlock(GuiGraphics g, double x, double y,
		double z, Vec3 cam, int fov, int color, String name)
	{
		double[] c = project(x, y, z, cam, fov);
		if(c == null)
			return;
		
		int sx = (int)c[0], sy = (int)c[1];
		double dist = Math.round(
			Math.sqrt((x - cam.x) * (x - cam.x)
				+ (y - cam.y) * (y - cam.y)
				+ (z - cam.z) * (z - cam.z)) * 10) / 10.0;
		if(dist > 96)
			return;
		
		g.drawString(MC.font, name + " " + dist + "m",
			sx - 20, sy - 40, color, true);
		
		// 方块 3D 线框（半格扩大显示）
		double h = 0.5;
		double[][] corners = {
			{x-h, y-h, z-h}, {x+h, y-h, z-h},
			{x+h, y-h, z+h}, {x-h, y-h, z+h},
			{x-h, y+h, z-h}, {x+h, y+h, z-h},
			{x+h, y+h, z+h}, {x-h, y+h, z+h}
		};
		int[][] edges = {{0,1},{1,2},{2,3},{3,0},
			{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
		for(int[] ed : edges)
			drawLine3D(g, corners[ed[0]], corners[ed[1]],
				cam, fov, color);
	}
	
	/** 3D 线段投影到屏幕并画线 */
	private static void drawLine3D(GuiGraphics g, double[] a,
		double[] b, Vec3 cam, int fov, int color)
	{
		double[] p1 = project(a[0], a[1], a[2], cam, fov);
		double[] p2 = project(b[0], b[1], b[2], cam, fov);
		if(p1 == null || p2 == null)
			return;
		
		int x1 = (int)p1[0], y1 = (int)p1[1];
		int x2 = (int)p2[0], y2 = (int)p2[1];
		
		int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1);
		int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
		int err = dx - dy;
		int x = x1, y = y1;
		while(true)
		{
			g.fill(x, y, x + 1, y + 1, color);
			if(x == x2 && y == y2)
				break;
			int e2 = 2 * err;
			if(e2 > -dy)
			{
				err -= dy;
				x += sx;
			}
			if(e2 < dx)
			{
				err += dx;
				y += sy;
			}
		}
	}
	
	/** 世界坐标 -> 屏幕坐标 */
	public static double[] project(double x, double y, double z,
		Vec3 cam, int fov)
	{
		double dx = x - cam.x, dy = y - cam.y, dz = z - cam.z;
		
		float yaw = (float)Math.toRadians(
			MC.player.getViewYRot(partialTick));
		float pitch = (float)Math.toRadians(
			MC.player.getViewXRot(partialTick));
		
		// 绕 Y 轴（yaw）
		double x1 = dx * Math.cos(-yaw) - dz * Math.sin(-yaw);
		double z1 = dx * Math.sin(-yaw) + dz * Math.cos(-yaw);
		// 绕 X 轴（pitch）
		double y2 = dy * Math.cos(pitch) - z1 * Math.sin(pitch);
		double z2 = dy * Math.sin(pitch) + z1 * Math.cos(pitch);
		
		if(z2 <= 0.05)
			return null;
		
		int width = MC.getWindow().getGuiScaledWidth();
		int height = MC.getWindow().getGuiScaledHeight();
		double focal = (height / 2.0)
			/ Math.tan(Math.toRadians(fov) / 2.0);
		
		double sx = width / 2.0 + x1 / z2 * focal;
		double sy = height / 2.0 - y2 / z2 * focal;
		
		if(sx < -200 || sx > width + 200
			|| sy < -200 || sy > height + 200)
			return null;
		
		return new double[] {sx, sy};
	}
}
