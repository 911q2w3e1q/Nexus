package net.nexus.render;

import net.nexus.NexusClient;
import net.nexus.hacks.PlayerEspHack;
import net.nexus.hacks.MobEspHack;
import net.nexus.hacks.ChestEspHack;
import net.nexus.hacks.ItemEspHack;
import net.nexus.util.Translate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;

public final class EspRenderer
{
	private static final Minecraft MC = Minecraft.getInstance();
	
	private static final java.util.List<net.minecraft.core.BlockPos>
		chestCache = new java.util.ArrayList<>();
	private static int scanTick;
	private static float partialTick;
	
	public static void render(GuiGraphics g, float tickDelta)
	{
		if(MC.player == null || MC.level == null)
			return;
		
		partialTick = tickDelta;
		
		boolean player = PlayerEspHack.isActive();
		boolean mob = MobEspHack.isActive();
		boolean chest = ChestEspHack.isActive();
		boolean item = ItemEspHack.isActive();
		if(!player && !mob && !chest && !item)
			return;
		
		Vec3 cam = MC.player.getEyePosition(tickDelta);
		int fov = MC.options.fov().get();
		
		// 定时扫描箱子
		scanTick++;
		if(chest && scanTick % 20 == 0)
		{
			chestCache.clear();
			net.minecraft.core.BlockPos center = MC.player.blockPosition();
			for(int dx = -20; dx <= 20; dx++)
				for(int dy = -6; dy <= 6; dy++)
					for(int dz = -20; dz <= 20; dz++)
					{
						net.minecraft.core.BlockPos pos =
							center.offset(dx, dy, dz);
						if(MC.level.getBlockState(pos).getBlock()
							instanceof net.minecraft.world.level.block.ChestBlock)
							chestCache.add(pos);
					}
		}
		
		// 实体
		for(Entity e : MC.level.entitiesForRendering())
		{
			if(e == MC.player)
				continue;
			if(e instanceof Player p && player)
				drawEntity(g, p, cam, fov, PlayerEspHack.getColor(),
					p.getDisplayName().getString());
			else if(e instanceof Monster m && mob)
				drawEntity(g, m, cam, fov, MobEspHack.getColor(),
					m.getType().getDescription().getString());
			else if(e instanceof ItemEntity i && item)
				drawEntity(g, i, cam, fov, ItemEspHack.getColor(),
					i.getItem().getHoverName().getString());
		}
		
		// 箱子
		if(chest)
			for(net.minecraft.core.BlockPos pos : chestCache)
				drawBlock(g, pos.getX() + 0.5, pos.getY() + 0.5,
					pos.getZ() + 0.5, cam, fov,
					ChestEspHack.getColor(), "箱子");
	}
	
	private static void drawEntity(GuiGraphics g, Entity e, Vec3 cam,
		int fov, int color, String name)
	{
		double x = e.getX(), y = e.getY() + e.getBbHeight() / 2,
			z = e.getZ();
		double[] s = project(x, y, z, cam, fov);
		if(s == null)
			return;
		
		int sx = (int)s[0], sy = (int)s[1];
		double dist = Math.round(e.distanceTo(MC.player) * 10) / 10.0;
		
		// 名字 + 距离
		g.drawString(MC.font, name + " " + dist + "m",
			sx - 20, sy - 14, color, true);
		
		// 2D 框：把实体投影成方框（简化：20x30 尺寸随距离缩放）
		double scale = 40.0 / Math.max(1.0, dist);
		int w = (int)(20 * scale), h = (int)(30 * scale);
		if(w < 6) w = 6;
		if(h < 9) h = 9;
		int x1 = sx - w / 2, y1 = sy - h / 2;
		int x2 = sx + w / 2, y2 = sy + h / 2;
		
		// 四边线框
		g.fill(x1, y1, x2, y1 + 1, color);
		g.fill(x1, y2, x2, y2 + 1, color);
		g.fill(x1, y1, x1 + 1, y2, color);
		g.fill(x2, y1, x2 + 1, y2, color);
	}
	
	private static void drawBlock(GuiGraphics g, double x, double y,
		double z, Vec3 cam, int fov, int color, String name)
	{
		double[] s = project(x, y, z, cam, fov);
		if(s == null)
			return;
		
		int sx = (int)s[0], sy = (int)s[1];
		double dist = Math.round(
			Math.sqrt((x - cam.x) * (x - cam.x)
				+ (y - cam.y) * (y - cam.y)
				+ (z - cam.z) * (z - cam.z)) * 10) / 10.0;
		
		g.drawString(MC.font, name + " " + dist + "m",
			sx - 20, sy - 14, color, true);
		
		double scale = 60.0 / Math.max(1.0, dist);
		int w = (int)(30 * scale), h = (int)(30 * scale);
		if(w < 8) w = 8;
		if(h < 8) h = 8;
		int x1 = sx - w / 2, y1 = sy - h / 2;
		int x2 = sx + w / 2, y2 = sy + h / 2;
		
		g.fill(x1, y1, x2, y1 + 1, color);
		g.fill(x1, y2, x2, y2 + 1, color);
		g.fill(x1, y1, x1 + 1, y2, color);
		g.fill(x2, y1, x2 + 1, y2, color);
	}
	
	/** 世界坐标 -> 屏幕坐标 */
	public static double[] project(double x, double y, double z,
		Vec3 cam, int fov)
	{
		double dx = x - cam.x, dy = y - cam.y, dz = z - cam.z;
		
		float yaw = (float)Math.toRadians(
			MC.player.getViewYRot(partialTick));
		float pitch = (float)Math.toRadians(
			MC.player.getViewXRot(partialTick));
		
		// 绕 Y 轴（yaw）
		double x1 = dx * Math.cos(-yaw) - dz * Math.sin(-yaw);
		double z1 = dx * Math.sin(-yaw) + dz * Math.cos(-yaw);
		// 绕 X 轴（pitch）
		double y2 = dy * Math.cos(pitch) - z1 * Math.sin(pitch);
		double z2 = dy * Math.sin(pitch) + z1 * Math.cos(pitch);
		
		if(z2 <= 0.05)
			return null;
		
		int width = MC.getWindow().getGuiScaledWidth();
		int height = MC.getWindow().getGuiScaledHeight();
		double focal = (height / 2.0)
			/ Math.tan(Math.toRadians(fov) / 2.0);
		
		double sx = width / 2.0 + x1 / z2 * focal;
		double sy = height / 2.0 - y2 / z2 * focal;
		
		if(sx < -200 || sx > width + 200
			|| sy < -200 || sy > height + 200)
			return null;
		
		return new double[] {sx, sy};
	}
}
