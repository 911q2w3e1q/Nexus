package net.nexus.hack;

import java.util.ArrayList;
import java.util.List;

import net.nexus.hacks.*;
import net.nexus.util.Translate;

public final class HackList
{
	private final List<Hack> hacks = new ArrayList<>();
	
	// 移动
	public final FlightHack flight = new FlightHack();
	public final FakeFlightHack fakeFlight = new FakeFlightHack();
	public final SpeedHack speed = new SpeedHack();
	public final LongJumpHack longJump = new LongJumpHack();
	public final AntiVoidHack antiVoid = new AntiVoidHack();
	public final VClipHack vClip = new VClipHack();
	public final FreezeHack freeze = new FreezeHack();
	public final HoleSnapHack holeSnap = new HoleSnapHack();
	public final NoFallHack noFall = new NoFallHack();
	public final JesusHack jesus = new JesusHack();
	
	// 战斗
	public final KillauraHack killaura = new KillauraHack();
	public final CrystalAuraHack crystalAura = new CrystalAuraHack();
	public final AutoClickerHack autoClicker = new AutoClickerHack();
	public final TargetStrafeHack targetStrafe = new TargetStrafeHack();
	public final BurrowHack burrow = new BurrowHack();
	public final AutoPearlHack autoPearl = new AutoPearlHack();
	public final AutoRodHack autoRod = new AutoRodHack();
	public final AutoShootHack autoShoot = new AutoShootHack();
	public final AntiCreeperHack antiCreeper = new AntiCreeperHack();
	
	// 世界
	public final ScaffoldHack scaffold = new ScaffoldHack();
	public final NukerHack nuker = new NukerHack();
	public final AutoToolHack autoTool = new AutoToolHack();
	public final SurroundHack surround = new SurroundHack();
	public final HoleFillHack holeFill = new HoleFillHack();
	public final AutoTrapHack autoTrap = new AutoTrapHack();
	public final WallHackHack wallHack = new WallHackHack();
	
	// 渲染
	public final FullbrightHack fullbright = new FullbrightHack();
	public final ZoomHack zoom = new ZoomHack();
	
	// 聊天/其他
	public final SpammerHack spammer = new SpammerHack();
	public final AutoGGHack autoGG = new AutoGGHack();
	public final AutoRespawnHack autoRespawn = new AutoRespawnHack();
	public final AutoWalkHack autoWalk = new AutoWalkHack();
	public final AutoSprintHack autoSprint = new AutoSprintHack();
	
	public HackList()
	{
		// 移动
		hacks.add(flight); hacks.add(fakeFlight); hacks.add(speed);
		hacks.add(longJump); hacks.add(antiVoid); hacks.add(vClip);
		hacks.add(freeze); hacks.add(holeSnap); hacks.add(noFall);
		hacks.add(jesus);
		// 战斗
		hacks.add(killaura); hacks.add(crystalAura); hacks.add(autoClicker);
		hacks.add(targetStrafe); hacks.add(burrow); hacks.add(autoPearl);
		hacks.add(autoRod); hacks.add(autoShoot); hacks.add(antiCreeper);
		// 世界
		hacks.add(scaffold); hacks.add(nuker); hacks.add(autoTool);
		hacks.add(surround); hacks.add(holeFill); hacks.add(autoTrap);
		hacks.add(wallHack);
		// 渲染
		hacks.add(fullbright); hacks.add(zoom);
		// 聊天/其他
		hacks.add(spammer); hacks.add(autoGG); hacks.add(autoRespawn);
		hacks.add(autoWalk); hacks.add(autoSprint);
		
		registerNames();
	}
	
	private void registerNames()
	{
		// 移动
		Translate.put("name.flight", "飞行");
		Translate.put("name.fakeflight", "假飞");
		Translate.put("name.speed", "加速");
		Translate.put("name.longjump", "远跳");
		Translate.put("name.antivoid", "防虚空");
		Translate.put("name.vclip", "垂直瞬移");
		Translate.put("name.freeze", "冻结");
		Translate.put("name.holesnap", "进洞吸附");
		Translate.put("name.nofall", "防摔落");
		Translate.put("name.jesus", "水上行走");
		// 战斗
		Translate.put("name.killaura", "杀戮光环");
		Translate.put("name.crystalaura", "水晶光环");
		Translate.put("name.autoclicker", "自动连点");
		Translate.put("name.targetstrafe", "环绕目标");
		Translate.put("name.burrow", "埋身");
		Translate.put("name.autopearl", "自动珍珠");
		Translate.put("name.autorod", "钓鱼竿连击");
		Translate.put("name.autoshoot", "自动投掷");
		Translate.put("name.anticreeper", "防苦力怕");
		// 世界
		Translate.put("name.scaffold", "自动搭路");
		Translate.put("name.nuker", "核爆挖矿");
		Translate.put("name.autotool", "自动选工具");
		Translate.put("name.surround", "环绕保护");
		Translate.put("name.holefill", "填洞");
		Translate.put("name.autotrap", "自动封人");
		Translate.put("name.wallhack", "隔墙透视");
		// 渲染
		Translate.put("name.fullbright", "亮度增强");
		Translate.put("name.zoom", "缩放");
		// 聊天/其他
		Translate.put("name.spammer", "刷屏机");
		Translate.put("name.autogg", "自动GG");
		Translate.put("name.autorespawn", "自动重生");
		Translate.put("name.autowalk", "自动行走");
		Translate.put("name.autosprint", "自动疾跑");
	}
	
	public void onTick()
	{
		for(Hack hack : hacks)
			if(hack.isEnabled())
				hack.onTick();
	}
	
	public List<Hack> getAll()
	{
		return hacks;
	}
}
