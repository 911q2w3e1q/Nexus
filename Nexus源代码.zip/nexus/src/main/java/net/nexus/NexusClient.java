package net.nexus;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.nexus.hack.Hack;
import net.nexus.hack.HackList;
import net.nexus.util.Translate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class NexusClient implements ClientModInitializer
{
	public static final String NAME = "Nexus Client";
	public static final String VERSION = "a1.0";
	public static final String MC_VERSION = "1.21.11";
	
	private static NexusClient INSTANCE;
	public final Minecraft MC = Minecraft.getInstance();
	public final HackList hackList = new HackList();
	private boolean guiKeyWasDown;
	
	@Override
	public void onInitializeClient()
	{
		INSTANCE = this;
		System.out.println("[NEXUS] onInitializeClient OK");
		
		// 每 tick
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			onTick();
			handleGuiKey();
		});
		
		// HUD 渲染
		HudRenderCallback.EVENT.register((graphics, tickDelta) -> {
			renderHud(graphics);
		});
	}
	
	public static NexusClient getInstance()
	{
		return INSTANCE;
	}
	
	public void onTick()
	{
		hackList.onTick();
	}
	
	private void handleGuiKey()
	{
		boolean down = org.lwjgl.glfw.GLFW.glfwGetKey(
			MC.getWindow().handle(), 344) == 1;
		if(down && !guiKeyWasDown)
		{
			if(MC.screen == null)
				MC.setScreen(new net.nexus.gui.ClickGuiScreen());
			else if(MC.screen instanceof net.nexus.gui.ClickGuiScreen)
				MC.setScreen(null);
		}
		guiKeyWasDown = down;
	}
	
	private void renderHud(GuiGraphics graphics)
	{
		if(MC.options.hideGui)
			return;
		
		// 左上角标题
		graphics.drawString(MC.font, NAME + " " + VERSION + " " + MC_VERSION,
			2, 2, 0xFFFFFF);
		
		// 已启用功能列表
		int y = 14;
		for(Hack hack : hackList.getAll())
		{
			if(!hack.isEnabled())
				continue;
			graphics.drawString(MC.font, Translate.name(hack.getName()),
				2, y, 0x00FF00);
			y += 10;
			if(y > 100)
				break;
		}

	}
}
